#!/bin/bash
sphinx-apidoc -f -e -o source /usr/share/cnchi

