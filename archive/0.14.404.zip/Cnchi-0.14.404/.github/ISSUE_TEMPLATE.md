### Problem:
*Replace this line with a brief summary of the problem.*

### Steps To Reproduce:
1.
2.
3.

### Log Files
- Use a service like http://paste2.org/ to provide links to the logs.
- Link to /tmp/cnchi.log output.
- Link to /tmp/postinstall.log.

### Additional Notes:

